from flask import Flask, flash, render_template, request, redirect, session, url_for, jsonify
from flask_mysqldb import MySQL
from flask_session import Session
from datetime import time, datetime, timedelta
import random
import traceback


app = Flask(__name__)
app.secret_key = 'clave_secreta'
app.config['SESSION_TYPE'] = 'filesystem'

# Configuración MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'FastLock'

Session(app)
mysql = MySQL(app)

#define el home
@app.route('/')
def home():
    return redirect('/login')

#define ruta login
@app.route('/login', methods=['GET', 'POST'])
def login():
    mensaje = ''
    if request.method == 'POST':
        rut = request.form['rut']
        contraseña = request.form['contraseña']
        
        cur = mysql.connection.cursor()

        # Validación para trabajadores (RUT sin formato, 5 dígitos)
        if re.match(r'^\d{5}$', rut):
            cur.execute("SELECT * FROM Trabajador WHERE Rutt = %s AND Contraseña = %s", (rut, contraseña))
            trabajador = cur.fetchone()
            if trabajador:
                session['admin'] = True
                cur.close()
                return redirect(url_for('admin'))
            else:
                mensaje = 'Credenciales de trabajador incorrectas.'
        
        # Validación para usuarios (RUT con formato XX.XXX.XXX-X)
        elif re.match(r'^\d{2}\.\d{3}\.\d{3}-[\dKk]$', rut):
            # Limpiar el RUT para la consulta en la BD
            rut_limpio = rut.replace(".", "").replace("-", "").upper()
            cur.execute("SELECT * FROM Usuarios WHERE Rut = %s AND Contraseña = %s", (rut_limpio, contraseña))
            user = cur.fetchone()
            if user:
                session['id_usuario'] = user[0]
                session['rol'] = 'usuario'
                session['nombre_usuario'] = user[1]
                cur.close()
                return redirect(url_for('inicio'))
            else:
                mensaje = 'Credenciales de usuario incorrectas.'
        else:
            mensaje = 'Formato de RUT no válido'

        cur.close()

    return render_template('login.html', mensaje=mensaje)

#Ruta inicio 
@app.route('/inicio')
def inicio():
    if 'id_usuario' in session and session['rol'] == 'usuario':
        return render_template('inicio.html')
    return redirect(url_for('login'))
    
#Ruta Register
import re
def validar_rut(rut_completo):
    try:
        # Verificar formato básico
        if not re.match(r'^\d{1,2}\.\d{3}\.\d{3}-[\dKk]$', rut_completo):
            return False
        
        # Limpiar RUT
        rut_limpio = rut_completo.replace(".", "").replace("-", "").upper()
        
        # Separar cuerpo y DV
        cuerpo = rut_limpio[:-1]
        dv = rut_limpio[-1]
        
        # Calcular DV correcto
        suma = 0
        multiplicador = 2
        
        for c in reversed(cuerpo):
            suma += int(c) * multiplicador
            multiplicador += 1
            if multiplicador == 8:
                multiplicador = 2
        
        resto = suma % 11
        dv_esperado = str(11 - resto) if resto != 0 else "0"
        dv_esperado = "K" if dv_esperado == "10" else dv_esperado
        
        return dv == dv_esperado
    except:
        return False
    
@app.route('/register', methods=['GET', 'POST'])
def register():
    mensaje = ''
    if request.method == 'POST':
        rut_original = request.form['rut']
        
        if not validar_rut(rut_original):
            mensaje = 'El RUT ingresado no es válido'
            return render_template('register.html', mensaje=mensaje)

        # Limpiar el RUT para almacenarlo
        rut_limpio = rut_original.replace(".", "").replace("-", "").upper()

        nombre = request.form['nombre']
        mail = request.form['email']
        telefono = request.form['telefono']
        contraseña = request.form['contraseña']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM Usuarios WHERE Rut = %s", (rut_limpio,))
        existente = cur.fetchone()

        if existente:
            mensaje = 'Este RUT ya está registrado. Intenta con otro.'
        else:
            cur.execute("INSERT INTO Usuarios (Rut, Nombre, Mail, Telefono, Contraseña) VALUES (%s, %s, %s, %s, %s)",
                        (rut_limpio, nombre, mail, telefono, contraseña))
            mysql.connection.commit()
            cur.close()
            return redirect('/login')

        cur.close()

    return render_template('register.html', mensaje=mensaje)

#Ruta del admin 
@app.route('/admin')
def admin():
    if not session.get('admin'):
        return redirect('/login')
    return render_template('admin.html')

#Ruta del logout
@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.clear()
    return redirect('/login')

#Ruta administrar productos  
@app.route('/admin_productos')
def admin_productos():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Producto")
    productos = cur.fetchall()
    cur.close()
    return render_template('admin_productos.html', productos=productos)

#Ruta editar productos
@app.route('/editar_producto', methods=['POST'])
def editar_producto():
    id_producto = request.form['id']
    nombre = request.form['nombre']
    stock = request.form['stock']
    precio = request.form['precio']
    fecha = request.form['fecha']

    cur = mysql.connection.cursor()
    cur.execute("""
        UPDATE Producto 
        SET Nombre=%s, Stock=%s, Precio=%s, Fecha=%s 
        WHERE IDProducto=%s
        """, (nombre, stock, precio, fecha, id_producto))
    mysql.connection.commit()
    cur.close()
    return redirect('/admin_productos')

#Ruta agregar producto 
@app.route('/agregar_producto', methods=['POST'])
def agregar_producto():
    nombre = request.form['nombre']
    stock = request.form['stock']
    precio = request.form['precio']
    fecha = request.form['fecha']

    cur = mysql.connection.cursor()
    cur.execute("""
        INSERT INTO Producto (Nombre, Stock, Precio, Fecha)
        VALUES (%s, %s, %s, %s)
        """, (nombre, stock, precio, fecha))
    mysql.connection.commit()
    cur.close()
    return redirect('/admin_productos')

#Ruta administrar usuarios 
@app.route('/admin_usuarios')
def admin_usuarios():
    if not session.get('admin'):
        return redirect('/login')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Usuarios")
    usuarios = cur.fetchall()
    cur.close()
    return render_template('admin_usuarios.html', usuarios=usuarios)

#Ruta Catalogo
@app.route('/catalogo')
def catalogo():
    if 'id_usuario' not in session:
        return redirect('/login')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM Producto")
    productos = cur.fetchall()
    cur.close()
    return render_template('catalogo.html', productos=productos)

#Ruta agregar carrito 
@app.route('/agregar_carrito_multiples', methods=['POST'])
def agregar_carrito_multiples():
    if 'id_usuario' not in session:
        return jsonify({'success': False, 'error': 'No autenticado'}), 401
    
    try:
        data = request.get_json()
        if not data or 'productos' not in data:
            return jsonify({'success': False, 'error': 'Datos inválidos'}), 400
        
        if 'carrito' not in session:
            session['carrito'] = []
        
        # Limpiar carrito antes de agregar nuevos productos
        session['carrito'] = []
        
        # Agregar productos con sus cantidades
        for producto in data['productos']:
            # Validar que la cantidad sea un número positivo
            cantidad = int(producto.get('cantidad', 0))
            if cantidad > 0:
                # Agregamos el producto ID la cantidad de veces especificada
                session['carrito'].extend([int(producto['id'])] * cantidad)
        
        session.modified = True  # Asegurar que la sesión se guarde
        return jsonify({'success': True, 'count': len(session['carrito'])})
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    
#Ruta visualizar carrito 
@app.route('/carrito')
def carrito():
    if 'id_usuario' not in session:
        return redirect('/login')
    
    carrito_ids = session.get('carrito', [])
    productos_con_info = []
    total = 0
    
    if carrito_ids:
        # Contar la cantidad de cada producto
        from collections import defaultdict
        cantidad_por_producto = defaultdict(int)
        for producto_id in carrito_ids:
            cantidad_por_producto[producto_id] += 1
        
        # Obtener información de los productos
        ids_unicos = list(cantidad_por_producto.keys())
        placeholders = ','.join(['%s'] * len(ids_unicos))
        cur = mysql.connection.cursor()
        cur.execute(f"""
            SELECT IDProducto, Nombre, Precio 
            FROM Producto 
            WHERE IDProducto IN ({placeholders})
            """, ids_unicos)
        
        productos_db = cur.fetchall()
        cur.close()
        
        # Preparar los datos para la plantilla
        for p in productos_db:
            producto_id = p[0]
            cantidad = cantidad_por_producto[producto_id]
            subtotal = p[2] * cantidad
            total += subtotal
            
            productos_con_info.append({
                'id': producto_id,
                'nombre': p[1],
                'precio': p[2],
                'cantidad': cantidad,
                'subtotal': subtotal
            })
    
    return render_template('carrito.html', 
                         productos=productos_con_info, 
                         total=total)

#Ruta visualizar pedidos 
@app.route('/pedidos')
def ver_pedidos():
    
    if 'id_usuario' not in session:
        session['mensaje'] = 'Debes iniciar sesión para acceder a esa página.'
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()
    
    # Asumimos que 'id_usuario' contiene el RUT limpio del usuario
    rut_usuario = session['id_usuario']

    cur.execute("""
        SELECT IDPedido, Fecha, Hora, Monto, MetPago, HoraRetiro, Estado
        FROM pedidos
        WHERE Rut = %s
        ORDER BY Fecha DESC, Hora DESC
    """, (rut_usuario,))

    pedidos = cur.fetchall()
    cur.close()

    return render_template('pedidos.html', pedidos=pedidos)


#Ruta horarios 
def generar_horarios_disponibles():
    from datetime import time, datetime, date

    # Obtener fecha y hora actual
    ahora = datetime.now()
    fecha_actual = ahora.date()
    hora_actual = ahora.time()

    # Definir rangos horarios
    bloques = [
        {'nombre': 'Mañana', 'inicio': time(9, 0), 'fin': time(13, 0)},
        {'nombre': 'Tarde', 'inicio': time(14, 0), 'fin': time(18, 0)}
    ]

    # Obtener horarios ocupados de la base de datos solo para hoy
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT HoraRetiro, COUNT(*) as total 
        FROM Pedidos 
        WHERE HoraRetiro IS NOT NULL 
        AND Fecha = %s
        GROUP BY HoraRetiro
    """, (fecha_actual,))

    ocupacion_por_hora = {}
    for hora, total in cur.fetchall():
        if isinstance(hora, timedelta):
            # Convertir timedelta a time
            total_seconds = hora.total_seconds()
            hours = int(total_seconds // 3600)
            minutes = int((total_seconds % 3600) // 60)
            hora_time = time(hour=hours, minute=minutes)
        else:
            hora_time = hora
        
        hora_str = hora_time.strftime("%H:%M")
        ocupacion_por_hora[hora_str] = total

    cur.close()

    horarios_disponibles = []

    for bloque in bloques:
        hora_actual_bloque = bloque['inicio']
        hora_fin_bloque = bloque['fin']

        inicio_min = hora_actual_bloque.hour * 60 + hora_actual_bloque.minute
        fin_min = hora_fin_bloque.hour * 60 + hora_fin_bloque.minute

        horarios_bloque = []

        while inicio_min <= fin_min:
            hora_obj = time(inicio_min // 60, inicio_min % 60)
            hora_str = hora_obj.strftime("%H:%M")
            
            # Verificar dos condiciones para disponibilidad:
            # 1. Que el horario no haya pasado ya
            # 2. Que no tenga 50 o más pedidos en ese horario
            horario_pasado = hora_obj < hora_actual
            horario_ocupado = ocupacion_por_hora.get(hora_str, 0) >= 50
            
            disponible = not horario_pasado and not horario_ocupado
            
            horarios_bloque.append({
                'hora': hora_str,
                'disponible': disponible,
                'motivo_no_disponible': "Horario pasado" if horario_pasado else 
                                      "No hay casilleros disponibles" if horario_ocupado else None
            })
            inicio_min += 10  # Incremento de 10 minutos

        horarios_disponibles.append({
            'nombre': bloque['nombre'],
            'horarios': [h for h in horarios_bloque if h['disponible'] or True]  # Mostrar todos con estado
        })

    return horarios_disponibles

#Ruta seleccionar horario
@app.route('/seleccionar_horario', methods=['GET', 'POST'])
def seleccionar_horario():
    if 'id_usuario' not in session:
        return redirect('/login')
    
    if not session.get('carrito'):
        return redirect('/carrito')
    
    horarios = generar_horarios_disponibles()
    return render_template('horarios.html', horarios=horarios)

#Ruta procesar horario
@app.route('/procesar_horario', methods=['POST'])
def procesar_horario():
    if 'id_usuario' not in session:
        return redirect('/login')

    carrito_ids = session.get('carrito')
    if not carrito_ids:
        return redirect('/carrito')

    horario_seleccionado = request.form.get('horario')
    if not horario_seleccionado:
        return "No se seleccionó ningún horario", 400

    try:
        hora_obj = datetime.strptime(horario_seleccionado, "%H:%M").time()

        cur = mysql.connection.cursor()
        try:
            from collections import defaultdict
            cantidades = defaultdict(int)
            for pid in carrito_ids:
                cantidades[int(pid)] += 1

            productos_ids = list(cantidades.keys())
            placeholders = ','.join(['%s'] * len(productos_ids))
            cur.execute(f"""
                SELECT IDProducto, Precio, Stock FROM Producto
                WHERE IDProducto IN ({placeholders})
            """, productos_ids)
            productos = cur.fetchall()

            total = 0
            for p in productos:
                total += p[1] * cantidades[p[0]]

            # Buscar el casillero más pequeño disponible para ese horario
            cur.execute("""
                SELECT IDLocker FROM Locker
                WHERE IDLocker NOT IN (
                    SELECT IDLocker FROM Pedidos WHERE HoraRetiro = %s
                )
                ORDER BY IDLocker ASC
                LIMIT 1
            """, (hora_obj,))
            casillero_disponible = cur.fetchone()
            if not casillero_disponible:
                return "No hay casilleros disponibles para el horario seleccionado", 400
            casillero = casillero_disponible[0]

            ahora = datetime.now()
            cur.execute("""
                INSERT INTO Pedidos (Rut, IDLocker, Rutt, Fecha, Hora, Monto, MetPago, HoraRetiro, Estado)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (session['id_usuario'], casillero, None, ahora.date(), ahora.time(), total, 'efectivo', hora_obj, 'pendiente'))

            pedido_id = cur.lastrowid

            # Insertar detalles y actualizar stock
            for p in productos:
                producto_id, precio, stock = p
                cantidad = cantidades[producto_id]

                if cantidad > stock:
                    mysql.connection.rollback()
                    return f"No hay suficiente stock para el producto {producto_id}", 400

                cur.execute("""
                    INSERT INTO Detalle (IDPedido, IDProducto, Cantidad)
                    VALUES (%s, %s, %s)
                """, (pedido_id, producto_id, cantidad))

                cur.execute("""
                    UPDATE Producto
                    SET Stock = Stock - %s
                    WHERE IDProducto = %s
                """, (cantidad, producto_id))

            mysql.connection.commit()
            session.pop('carrito', None)
            return render_template("confirmacion.html", casillero=casillero)

        except Exception as e:
            mysql.connection.rollback()
            print(f"Error al crear pedido: {e}")
            print(traceback.format_exc())
            return "Error al procesar el pedido", 500
        finally:
            cur.close()

    except ValueError:
        return "Formato de hora inválido. Use HH:MM", 400



#Ruta para administrar pedidos(trabajador)
@app.route('/admin_pedidos')
def admin_pedidos():
    if not session.get('admin'):
        return redirect('/login')
    
    # Obtener la fecha actual
    fecha_actual = datetime.now().strftime('%Y-%m-%d')
    
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT idpedido, fecha, hora, monto, metpago, horaRetiro, estado 
        FROM pedidos 
        WHERE fecha = %s 
        ORDER BY hora DESC
    """, (fecha_actual,))
    pedidos = cur.fetchall()
    cur.close()
    
    return render_template('admin_pedidos.html', pedidos=pedidos)

#Ruta para obtener información del pedido
@app.route('/detalles_pedido/<int:id_pedido>')
def detalles_pedido(id_pedido):
    if not session.get('admin'):
        return redirect('/login')
    
    cur = mysql.connection.cursor()
    
    cur.execute("""
        SELECT idpedido, fecha, hora, monto, metpago, horaRetiro, estado  
        FROM pedidos 
        WHERE idpedido = %s
    """, (id_pedido,))
    pedido = cur.fetchone()

    if not pedido:
        return None, None  # No se encontró el pedido

    # Obtener los productos del pedido
    cur.execute("""
    SELECT 
        p.nombre, 
        dp.cantidad, 
        p.precio AS precio_unitario,  -- Obtén el precio unitario desde la tabla producto
        (dp.cantidad * p.precio) AS subtotal  -- Calcula el subtotal (cantidad * precio unitario)
    FROM detalle dp
    JOIN producto p ON dp.idproducto = p.idproducto
    WHERE dp.idpedido = %s
    """, (id_pedido,))
    productos = cur.fetchall()
    cur.close()

    return render_template('detalles_pedido.html', pedido=pedido, productos=productos)

#Ruta para cambiar el estado del pedido
@app.route('/cambiar_estado_pedido/<int:id_pedido>', methods=['POST'])
def cambiar_estado_pedido(id_pedido):
    if not session.get('admin'):
        return redirect('/login')
    
    cur = mysql.connection.cursor()
    cur.execute("""
        UPDATE pedidos 
        SET estado = 'Finalizado' 
        WHERE idpedido = %s AND estado = 'Pendiente'
    """, (id_pedido,))
    mysql.connection.commit()
    cur.close()
    
    flash('El estado del pedido ha sido actualizado a "Finalizado"', 'success')
    return redirect(url_for('detalles_pedido', id_pedido=id_pedido))


#Fin
if __name__ == '__main__':
    app.run(debug=True)


